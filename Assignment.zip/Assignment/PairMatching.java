import java.util.*;
class PairMatching 
{
public static void main(String args[])
{
Scanner obj=new Scanner(System.in);
int n = obj.nextInt();
int arr[]=new int[n];
int temp;
int total=0;
int length=arr.length;
int p=length;

// input array 
System.out.println("Enter Element :-  "); 

for(int i=0;i<length;i++)
{
arr[i]=obj.nextInt();
}

// Sort the array in ascending order
 Arrays.sort(arr); // use predefine function used to sort array 

// Another Method using sort array
/* 
for(int j=0;j<length;j++)
{
for(int k=j+1;k<length;k++)
{
if(arr[j]>arr[k])
{
temp=arr[j];
arr[j]=arr[k];
arr[k]=temp;
}
}
} 
*/
System.out.print("["); 

for(int i=0;i<length;i++)
{
System.out.print(arr[i]);
if(p>1)
{
System.out.print(",");
p--;
} 
} 

System.out.println("]"); 
// pair matching socks

for(int l=0;l< length-1;l++)
{
if(l<n && arr[l]==arr[l+1]) 
{
total++;
l=l+1;
}
}

System.out.println(total);
}
}